
from langchain_anthropic import ChatAnthropic
from langchain_openai import ChatOpenAI
from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()
os.getenv('OPENAI_API_KEY')
os.getenv('OPENAI_API_KEY')
os.getenv('ANTHROPIC_API_KEY')
os.getenv('PERPLEXITY_API_KEY')


anthropic = ChatAnthropic(
    model="claude-3-5-sonnet-20240620",
    max_tokens_to_sample=8192,
    temperature=0.8)

gpt4o = ChatOpenAI(
    model="gpt-4o",
    temperature=0.8)

gpt4o_mini = ChatOpenAI(
    model="gpt-4o-mini",
    temperature=0.8)

client = OpenAI(base_url="https://api.perplexity.ai")
perplexity = "llama-3.1-sonar-small-128k-online"