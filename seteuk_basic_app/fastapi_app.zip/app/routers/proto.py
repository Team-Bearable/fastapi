from fastapi import APIRouter
from langchain_core.runnables import RunnablePassthrough
from langchain_core.prompts import ChatPromptTemplate
from utils.model import anthropic, gpt4o, gpt4o_mini
from utils.prompt import seteukBasicBodyTop, seteukBasicProto, perplexity_prompt, material_organizer
from langchain_core.output_parsers import StrOutputParser
from fastapi import APIRouter
from langchain_openai import ChatOpenAI

from pydantic import BaseModel

# class RequestModel(BaseModel):
#     major: str
#     keyword: str
#     topic: str
router = APIRouter()


# @router.post("/proto")
# async def seteukProto(payload: RequestModel):
#     # 테스트용 기본 응답 데이터 생성
#     major = payload.major
#     keyword = payload.keyword
#     topic = payload.topic

#     # 여기서 실제 모델 호출 대신 임시 응답값 반환
#     test_result = {
#         "major": major or "default_major",
#         "keyword": keyword or "default_keyword",
#         "topic": topic or "default_topic",
#         "response": f"Processed: {major}, {keyword}, {topic}"
#     }
#     return test_result

@router.post("/proto")
async def seteukProto(major, keyword, topic):
    tp_cs = seteukBasicProto()
    topic_prompt = ChatPromptTemplate.from_messages(
        [
            ("system", tp_cs.system),
            ("user", tp_cs.human),
        ]
    )
    gpt4o = ChatOpenAI(
        model="gpt-4o",
        temperature=0.8)
    chain_gpt  = {"major": RunnablePassthrough(), 'keyword': RunnablePassthrough(), 'topic': RunnablePassthrough()}|topic_prompt | gpt4o | StrOutputParser()

    result = chain_gpt.invoke({'major':major, 'keyword':keyword, 'topic': topic})
    # result = gpt4o.invoke("안녕")
    json_result = eval(result)
    # result = (major, keyword, topic)
    return json_result
